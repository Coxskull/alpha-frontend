"use client";

import api from "./api";


// ======================================================
// TYPES
// ======================================================

export interface AssignSupplierPayload {
  supplierId: number;
}

export interface AssignDriverPayload {
  driverId: number;
}

export interface UploadProofPayload {
  proofImageUrl: string;
}


// ======================================================
// GET ALL ORDERS
// ======================================================

export const getOrders = async () => {

  const response =
    await api.get("/Orders");

  return response.data;
};


// ======================================================
// GET ORDER BY ID
// ======================================================

export const getOrderById = async (
  id: number
) => {

  const response =
    await api.get(`/Orders/${id}`);

  return response.data;
};


// ======================================================
// GET ORDER STATUS
// ======================================================

export const getOrderStatus = async (
  id: number
) => {

  const response =
    await api.get(
      `/Orders/${id}/status`
    );

  return response.data;
};


// ======================================================
// ASSIGN SUPPLIER
// ======================================================

export const assignSupplier = async (
  id: number,
  payload: AssignSupplierPayload
) => {

  const response =
    await api.post(
      `/Orders/${id}/assign-supplier`,
      payload
    );

  return response.data;
};


// ======================================================
// ASSIGN DRIVER
// ======================================================

export const assignDriver = async (
  id: number,
  payload: AssignDriverPayload
) => {

  const response =
    await api.post(
      `/Orders/${id}/assign-driver`,
      payload
    );

  return response.data;
};


// ======================================================
// MARK PICKED UP
// ======================================================

export const markPickedUp = async (
  id: number
) => {

  const response =
    await api.post(
      `/Orders/${id}/picked-up`
    );

  return response.data;
};


// ======================================================
// MARK EN ROUTE
// ======================================================

export const markEnRoute = async (
  id: number
) => {

  const response =
    await api.post(
      `/Orders/${id}/en-route`
    );

  return response.data;
};


// ======================================================
// MARK DELIVERED
// ======================================================

export const markDelivered = async (
  id: number
) => {

  const response =
    await api.post(
      `/Orders/${id}/delivered`
    );

  return response.data;
};


// ======================================================
// UPLOAD DELIVERY PROOF
// ======================================================

export const uploadProof = async (
  id: number,
  payload: UploadProofPayload
) => {

  const response =
    await api.post(
      `/Orders/${id}/proof`,
      payload
    );

  return response.data;
};