"use client";

"use client";

import {
  List,
  Datagrid,
  TextField,
  DateField,
  FunctionField,
} from "react-admin";

import StatusChip
from "../../components/StatusChip";

export default function OrdersList() {
  return (
    <List>
      <Datagrid rowClick="show">

        <TextField source="orderNumber" />
        <TextField source="customerName" />
        <TextField source="itemDescription" />
        <TextField source="pickupAddress" />
        <TextField source="deliveryAddress" />
<FunctionField
  label="Status"
  render={(record: { status: string }) => (
    <StatusChip
      status={record.status}
    />
  )}
/>
        <DateField source="createdAt" />
        <DateField source="updatedAt" />

      </Datagrid>
    </List>
  );
}