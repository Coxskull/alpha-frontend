export interface Order {

  id: number;

  orderNumber: string;

  customerName: string;

  itemDescription: string;

  pickupAddress: string;

  deliveryAddress: string;

  supplierId?: number;

  driverId?: number;

  supplierName?: string;

  driverName?: string;

  status: string;

  proofImageUrl?: string;

  createdAt: string;

  updatedAt: string;
}


export interface Supplier {

  id: number;

  name: string;

  availabilityStatus:
    | "available"
    | "busy"
    | "closed";
}


export interface Driver {

  id: number;

  name: string;

  availabilityStatus:
    | "available"
    | "delivering"
    | "offline";
}