"use client";

import { useEffect, useState } from "react";

import {
  Package,
  Bike,
  Store,
  Truck,
  CheckCircle2,
} from "lucide-react";

import api from "../../services/api";

import StatusCard from "./StatusCard";

import {
  Driver,
  Supplier,
  Order,
} from "../../types/dashboard";

export default function StatusCards() {

  // =====================================================
  // STATE
  // =====================================================

  const [stats, setStats] = useState({
    activeOrders: 0,
    availableDrivers: 0,
    activeSuppliers: 0,
    enRouteDeliveries: 0,
    deliveredToday: 0,
  });

  const [loading, setLoading] =
    useState(true);

  // =====================================================
  // LOAD DASHBOARD
  // =====================================================

  const loadDashboard = async () => {

    try {

      setLoading(true);

      // ============================================
      // API CALLS
      // ============================================

      const [
        ordersResponse,
        driversResponse,
        suppliersResponse,
      ] = await Promise.all([
        api.get("/Orders"),
        api.get("/Drivers"),
        api.get("/Suppliers"),
      ]);

      const orders: Order[] =
        ordersResponse.data;

      const drivers: Driver[] =
        driversResponse.data;

      const suppliers: Supplier[] =
        suppliersResponse.data;

      // ============================================
      // CALCULATED COUNTS
      // ============================================

      const activeOrdersCount =
        orders.length;

      const availableDriversCount =
        drivers.filter(
          (driver) =>
            driver.availabilityStatus ===
            "available"
        ).length;

      const activeSuppliersCount =
        suppliers.filter(
          (supplier) =>
            supplier.availabilityStatus ===
            "available"
        ).length;

      const enRouteCount =
        orders.filter(
          (order) =>
            order.status ===
            "en_route"
        ).length;

      const deliveredCount =
        orders.filter(
          (order) =>
            order.status ===
            "delivered"
        ).length;

      // ============================================
      // SINGLE STATE UPDATE
      // ============================================

      setStats({
        activeOrders:
          activeOrdersCount,

        availableDrivers:
          availableDriversCount,

        activeSuppliers:
          activeSuppliersCount,

        enRouteDeliveries:
          enRouteCount,

        deliveredToday:
          deliveredCount,
      });

    } catch (error) {

      console.error(
        "Dashboard Load Error:",
        error
      );

    } finally {

      setLoading(false);

    }
  };

  // =====================================================
  // AUTO REFRESH
  // =====================================================

  useEffect(() => {

    let mounted = true;

    const fetchDashboard =
      async () => {

        if (!mounted) return;

        await loadDashboard();

      };

    // ============================================
    // INITIAL LOAD
    // ============================================

    fetchDashboard();

    // ============================================
    // AUTO REFRESH
    // ============================================

    const interval =
      setInterval(() => {

        fetchDashboard();

      }, 15000);

    // ============================================
    // CLEANUP
    // ============================================

    return () => {

      mounted = false;

      clearInterval(interval);

    };

  }, []);

  // =====================================================
  // UI
  // =====================================================

  return (

    <div
  className="
    grid
    grid-cols-1
    sm:grid-cols-2
    xl:grid-cols-5
    gap-6
  "
>

      {/* ========================================= */}
      {/* ACTIVE ORDERS */}
      {/* ========================================= */}

      <StatusCard
        title="Active Orders"
        value={stats.activeOrders}
        icon={
          <Package size={26} />
        }
        color="#3B82F6"
        loading={loading}
      />

      {/* ========================================= */}
      {/* AVAILABLE DRIVERS */}
      {/* ========================================= */}

      <StatusCard
        title="Available Drivers"
        value={stats.availableDrivers}
        icon={
          <Bike size={26} />
        }
        color="#10B981"
        loading={loading}
      />

      {/* ========================================= */}
      {/* ACTIVE SUPPLIERS */}
      {/* ========================================= */}

      <StatusCard
        title="Active Suppliers"
        value={stats.activeSuppliers}
        icon={
          <Store size={26} />
        }
        color="#F59E0B"
        loading={loading}
      />

      {/* ========================================= */}
      {/* EN ROUTE */}
      {/* ========================================= */}

      <StatusCard
        title="En Route"
        value={stats.enRouteDeliveries}
        icon={
          <Truck size={26} />
        }
        color="#8B5CF6"
        loading={loading}
      />

      {/* ========================================= */}
      {/* DELIVERED */}
      {/* ========================================= */}

      <StatusCard
        title="Delivered Today"
        value={stats.deliveredToday}
        icon={
          <CheckCircle2 size={26} />
        }
        color="#10B981"
        loading={loading}
      />

    </div>
  );
}