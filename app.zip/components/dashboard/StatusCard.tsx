interface Props {
  title: string;
  value: number;
  icon: React.ReactNode;
  color: string;
  loading?: boolean;
}

export default function StatusCard({
  title,
  value,
  icon,
  color,
  loading,
}: Props) {

  return (

    <div
      className="
        relative
        overflow-hidden
        bg-white
        border
        border-gray-200
        rounded-3xl
        p-6
        shadow-sm
        transition-all
        duration-300
        hover:shadow-lg
        hover:-translate-y-1
      "
    >

      <div
        className="
          flex
          items-start
          justify-between
        "
      >

        <div>

          <p
            className="
              text-sm
              font-medium
              text-gray-500
            "
          >
            {title}
          </p>

          <h2
            className="
              text-5xl
              font-bold
              mt-5
              tracking-tight
              text-[#111827]
            "
          >
            {loading ? "--" : value}
          </h2>

        </div>

        <div
          style={{
            backgroundColor: `${color}15`,
            color,
          }}
          className="
            w-16
            h-16
            rounded-2xl
            flex
            items-center
            justify-center
          "
        >
          {icon}
        </div>

      </div>

    </div>
  );
}