"use client";

import {
  useEffect,
  useState,
} from "react";

import api
from "../../services/api";

import StatusChip
from "../StatusChip";

type Order = {
  id: string;
  orderNumber: string;
  customerName: string;
  itemDescription: string;
  pickupAddress: string;
  deliveryAddress: string;
  status: string;
  createdAt: string;
};

export default function ActiveOrdersTable() {

  const [orders, setOrders] =
    useState<Order[]>([]);

  const [loading, setLoading] =
    useState(true);

  useEffect(() => {

    let isMounted = true;

    const fetchOrders = async () => {

      try {

        const response =
          await api.get("/Orders");

        if (isMounted) {

          setOrders(response.data);

        }

      } catch (error) {

        console.error(error);

      } finally {

        if (isMounted) {

          setLoading(false);

        }

      }

    };

    fetchOrders();

    const interval =
      setInterval(fetchOrders, 15000);

    return () => {

      isMounted = false;

      clearInterval(interval);

    };

  }, []);

  return (

    <div
      className="
        bg-white
        border
        border-gray-200
        rounded-3xl
        overflow-hidden
        shadow-sm
      "
    >

      {/* HEADER */}

      <div
        className="
          flex
          items-center
          justify-between
          px-8
          py-6
          border-b
          border-gray-200
        "
      >

        <div>

          <h2
            className="
              text-2xl
              font-bold
              text-[#111827]
            "
          >
            Active Orders
          </h2>

          <p
            className="
              text-sm
              text-gray-500
              mt-1
            "
          >
            Monitor and manage dispatch operations
          </p>

        </div>

        <div
          className="
            px-4
            py-2
            rounded-xl
            bg-gray-100
            text-sm
            text-gray-600
            font-medium
          "
        >
          {orders.length} Orders
        </div>

      </div>

      {/* TABLE */}

      <div className="overflow-x-auto">

        <table
          className="
            w-full
            min-w-[1000px]
          "
        >

          <thead
            className="
              bg-gray-50
              text-gray-500
              text-sm
            "
          >

            <tr>

              <th className="px-8 py-5 text-left">
                Order #
              </th>

              <th className="px-8 py-5 text-left">
                Customer
              </th>

              <th className="px-8 py-5 text-left">
                Item
              </th>

              <th className="px-8 py-5 text-left">
                Pickup
              </th>

              <th className="px-8 py-5 text-left">
                Delivery
              </th>

              <th className="px-8 py-5 text-left">
                Status
              </th>

              <th className="px-8 py-5 text-left">
                Created
              </th>

            </tr>

          </thead>

          <tbody>

            {orders.map((order) => (

              <tr
                key={order.id}
                className="
                  border-t
                  border-gray-100
                  hover:bg-gray-50
                  transition-all
                "
              >

                <td
                  className="
                    px-8
                    py-6
                    font-semibold
                    text-blue-600
                  "
                >
                  {order.orderNumber}
                </td>

                <td className="px-8 py-6 text-[#111827]">
                  {order.customerName}
                </td>

                <td className="px-8 py-6 text-gray-700">
                  {order.itemDescription}
                </td>

                <td className="px-8 py-6 text-gray-500">
                  {order.pickupAddress}
                </td>

                <td className="px-8 py-6 text-gray-500">
                  {order.deliveryAddress}
                </td>

                <td className="px-8 py-6">
                  <StatusChip
                    status={order.status}
                  />
                </td>

                <td
                  className="
                    px-8
                    py-6
                    text-gray-400
                    text-sm
                  "
                >
                  {new Date(
                    order.createdAt
                  ).toLocaleString()}
                </td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

      {loading && (
        <div
          className="
            p-6
            text-center
            text-gray-500
          "
        >
          Loading orders...
        </div>
      )}

    </div>
  );
}