"use client";

import Sidebar from "./layout/Sidebar";
import Topbar from "./layout/Topbar";

export default function AdminApp({
  children,
}: {
  children: React.ReactNode;
}) {

  return (

    <div
      className="
        flex
        min-h-screen
        bg-[#F3F4F6]
      "
    >

      {/* SIDEBAR */}

      <Sidebar />

      {/* MAIN */}

      <div
        className="
          flex-1
          flex
          flex-col
          overflow-hidden
        "
      >

        {/* TOPBAR */}

        <Topbar />

        {/* CONTENT */}

        <main
          className="
            flex-1
            overflow-y-auto
            p-8
            bg-[#F3F4F6]
          "
        >

          {/* WHITE PANEL */}

          <div
            className="
              bg-white
              rounded-[32px]
              min-h-full
              p-8
              shadow-sm
              border
              border-gray-200
            "
          >

            {children}

          </div>

        </main>

      </div>

    </div>
  );
}