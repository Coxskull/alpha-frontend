"use client";

type Props = {
  status: string;
};

export default function StatusChip({
  status,
}: Props) {

  const getStyles = () => {

    switch (status) {

      case "pending":
        return "bg-yellow-100 text-yellow-700";

      case "supplier_assigned":
        return "bg-blue-100 text-blue-700";

      case "driver_assigned":
        return "bg-indigo-100 text-indigo-700";

      case "picked_up":
        return "bg-orange-100 text-orange-700";

      case "en_route":
        return "bg-purple-100 text-purple-700";

      case "delivered":
        return "bg-green-100 text-green-700";

      case "proof_uploaded":
        return "bg-emerald-100 text-emerald-700";

      case "available":
        return "bg-green-100 text-green-700";

      case "busy":
        return "bg-yellow-100 text-yellow-700";

      case "offline":
        return "bg-gray-100 text-gray-700";

      case "closed":
        return "bg-red-100 text-red-700";

      case "delivering":
        return "bg-blue-100 text-blue-700";

      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (

    <span
      className={`
        inline-flex
        items-center
        px-3
        py-1
        rounded-full
        text-xs
        font-semibold
        capitalize
        ${getStyles()}
      `}
    >
      {status.replaceAll("_", " ")}
    </span>

  );
}