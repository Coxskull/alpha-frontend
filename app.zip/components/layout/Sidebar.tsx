"use client";

import Link from "next/link";

import { usePathname }
from "next/navigation";

import {
  LayoutDashboard,
  Package,
  Truck,
  Store,
  BarChart3,
  Settings,
} from "lucide-react";

import AlphaLogo
from "../branding/AlphaLogo";

const menuItems = [
  {
    label: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    label: "Orders",
    href: "/#/Orders",
    icon: Package,
  },
  {
    label: "Drivers",
    href: "/drivers",
    icon: Truck,
  },
  {
    label: "Suppliers",
    href: "/suppliers",
    icon: Store,
  },
  {
    label: "Analytics",
    href: "/analytics",
    icon: BarChart3,
  },
  {
    label: "Settings",
    href: "/settings",
    icon: Settings,
  },
];

export default function Sidebar() {

  const pathname =
    usePathname();

  return (

    <aside
      className="
        w-[280px]
        min-h-screen
        bg-white
border-gray-200
        border-r
        flex
        flex-col
        px-5
        py-6
      "
    >

      <div className="mb-10">

        <AlphaLogo />

      </div>

      <nav
        className="
          flex
          flex-col
          gap-2
        "
      >

        {menuItems.map((item) => {

          const Icon =
            item.icon;

          const isActive =
            pathname === item.href;

          return (

            <Link
              key={item.label}
              href={item.href}
              className={`
                flex
                items-center
                gap-4
                px-5
                py-4
                rounded-2xl
                transition-all
                duration-300

                ${
                  isActive
                    ? `
                      bg-gradient-to-r
                      from-[#3B82F6]
                      to-[#2563EB]
                      text-white
                      shadow-lg
                    `
                    : `
                      text-gray-500
                      hover:bg-white/[0.03]
                      hover:text-[#111827]
                    `
                }
              `}
            >

              <Icon size={20} />

              <span
                className="
                  font-medium
                  text-[15px]
                "
              >
                {item.label}
              </span>

            </Link>

          );
        })}

      </nav>

      <div className="mt-auto">

        <div
          className="
            bg-gradient-to-br
            from-[#1E3A8A]
            to-[#2563EB]
            rounded-3xl
            p-5
            shadow-2xl
          "
        >

          <p
            className="
              text-white
              font-semibold
            "
          >
            Mission Control
          </p>

          <p
            className="
              text-blue-100
              text-sm
              mt-2
              leading-relaxed
            "
          >
            Real-time dispatch operations platform.
          </p>

          <div
            className="
              mt-5
              flex
              items-center
              gap-2
            "
          >

            <div
              className="
                w-3
                h-3
                rounded-full
                bg-[#10B981]
                animate-pulse
              "
            />

            <span
              className="
                text-sm
                text-green-200
              "
            >
              System Online
            </span>

          </div>

        </div>

      </div>

    </aside>
  );
}