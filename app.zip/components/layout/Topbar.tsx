"use client";

import {
  Bell,
  Search,
  UserCircle2,
} from "lucide-react";

export default function Topbar() {

  return (

    <header
      className="
        sticky
        top-0
        z-50
        h-[90px]
        bg-white/90
        backdrop-blur-xl
        border-b
        border-gray-200
        flex
        items-center
        justify-between
        px-8
      "
    >

      {/* SEARCH */}

      <div
        className="
          flex
          items-center
          gap-3
          w-[420px]
          bg-white
          border
          border-gray-200
          rounded-2xl
          px-5
          py-4
        "
      >

        <Search
          size={18}
          className="
            text-[#9CA3AF]
          "
        />

        <input
          type="text"
          placeholder="
            Search orders,
            drivers,
            suppliers...
          "
          className="
            bg-transparent
            outline-none
            w-full
            text-white
            placeholder:text-[#6B7280]
          "
        />

      </div>

      {/* RIGHT */}

      <div
        className="
          flex
          items-center
          gap-5
        "
      >

        {/* NOTIFICATION */}

        <button
          className="
            relative
            w-14
            h-14
            rounded-2xl
            bg-white
            border
            border-gray-200
            flex
            items-center
            justify-center
            hover:border-[#3B82F6]
            transition-all
          "
        >

          <Bell
            size={20}
            className="
              text-[#F3F4F6]
            "
          />

          <div
            className="
              absolute
              top-3
              right-3
              w-2.5
              h-2.5
              rounded-full
              bg-[#EF4444]
            "
          />

        </button>

        {/* USER */}

        <div
          className="
            flex
            items-center
            gap-4
            bg-white
            border
            border-gray-200
            rounded-2xl
            px-5
            py-3
          "
        >

          <UserCircle2
            size={42}
            className="
              text-[#3B82F6]
            "
          />

          <div>

            <p
              className="
                text-white
                font-semibold
              "
            >
              Dispatcher
            </p>

            <p
              className="
                text-sm
                text-[#9CA3AF]
              "
            >
              Alpha Operations
            </p>

          </div>

        </div>

      </div>

    </header>
  );
}