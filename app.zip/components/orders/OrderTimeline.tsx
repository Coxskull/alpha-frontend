"use client";

import {
  Box,
  Typography,
  Chip,
} from "@mui/material";

import {
  CheckCircle,
} from "@mui/icons-material";

// =====================================================
// TYPES
// =====================================================

type TimelineItem = {
  status: string;
  timestamp?: string;
};

type Props = {
  currentStatus: string;
  history?: TimelineItem[];
};

// =====================================================
// STATUS CONFIG
// =====================================================

const timelineSteps = [

  {
    key: "pending",
    label: "Pending",
    color: "#EAB308",
  },

  {
    key: "supplier_assigned",
    label: "Supplier Assigned",
    color: "#3B82F6",
  },

  {
    key: "driver_assigned",
    label: "Driver Assigned",
    color: "#6366F1",
  },

  {
    key: "picked_up",
    label: "Picked Up",
    color: "#F97316",
  },

  {
    key: "en_route",
    label: "En Route",
    color: "#A855F7",
  },

  {
    key: "delivered",
    label: "Delivered",
    color: "#22C55E",
  },

  {
    key: "proof_uploaded",
    label: "Proof Uploaded",
    color: "#10B981",
  },

];

// =====================================================
// COMPONENT
// =====================================================

export default function OrderTimeline({
  currentStatus,
  history = [],
}: Props) {

  const currentIndex =
    timelineSteps.findIndex(
      (step) => step.key === currentStatus
    );

  return (

    <Box>

      <Typography
        variant="h6"
        fontWeight="bold"
        mb={3}
        color="white"
      >
        🕒 Delivery Timeline
      </Typography>

      <Box
        sx={{
          position: "relative",
          ml: 2,
        }}
      >

        {timelineSteps.map(
          (step, index) => {

            const isCompleted =
              index <= currentIndex;

            const historyItem =
              history.find(
                (h) =>
                  h.status === step.key
              );

            return (

              <Box
                key={step.key}
                sx={{
                  display: "flex",
                  position: "relative",
                  mb: 4,
                }}
              >

                {/* ================================= */}
                {/* LINE */}
                {/* ================================= */}

                {index !==
                  timelineSteps.length - 1 && (
                  <Box
                    sx={{
                      position: "absolute",
                      left: 15,
                      top: 35,
                      width: "3px",
                      height: "100%",
                      background:
                        isCompleted
                          ? `linear-gradient(to bottom, ${step.color}, #1F2937)`
                          : "#374151",
                      transition:
                        "all 0.4s ease",
                    }}
                  />
                )}

                {/* ================================= */}
                {/* NODE */}
                {/* ================================= */}

                <Box
                  sx={{
                    width: 34,
                    height: 34,
                    borderRadius: "50%",
                    backgroundColor:
                      isCompleted
                        ? step.color
                        : "#1F2937",
                    display: "flex",
                    alignItems: "center",
                    justifyContent:
                      "center",
                    zIndex: 2,
                    boxShadow:
                      isCompleted
                        ? `0 0 15px ${step.color}`
                        : "none",
                    transition:
                      "all 0.3s ease",
                  }}
                >

                  {isCompleted && (
                    <CheckCircle
                      sx={{
                        color: "white",
                        fontSize: 20,
                      }}
                    />
                  )}

                </Box>

                {/* ================================= */}
                {/* CONTENT */}
                {/* ================================= */}

                <Box ml={3}>

                  <Chip
                    label={step.label}
                    sx={{
                      backgroundColor:
                        isCompleted
                          ? step.color
                          : "#1F2937",

                      color: "white",

                      fontWeight: "bold",

                      mb: 1,
                    }}
                  />

                  <Typography
                    variant="body2"
                    color="#94A3B8"
                  >

                    {historyItem?.timestamp
                      ? new Date(
                          historyItem.timestamp
                        ).toLocaleString()
                      : "Waiting..."}

                  </Typography>

                </Box>

              </Box>
            );
          }
        )}

      </Box>

    </Box>
  );
}
