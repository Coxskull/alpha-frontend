"use client";

import {
  Activity,
  RefreshCcw,
} from "lucide-react";

import StatusCards
from "../../components/dashboard/StatusCards";

import ActiveOrdersTable
from "../../components/dashboard/ActiveOrdersTable";

import AvailabilityBoard
from "../../components/providers/AvailabilityBoard";

export default function Dashboard() {

  return (

    <div className="space-y-8">

      {/* HEADER */}

      <div
        className="
          flex
          flex-col
          xl:flex-row
          xl:items-start
          xl:justify-between
          gap-8
        "
      >

        {/* LEFT */}

        <div>

          <div
            className="
              inline-flex
              items-center
              gap-2
              px-4
              py-2
              rounded-full
              bg-green-50
              border
              border-green-200
              text-sm
              text-green-700
              mb-5
            "
          >

            <Activity size={16} />

            Dispatch System Operational

          </div>

          <h1
            className="
              text-5xl
              font-bold
              tracking-tight
              text-[#111827]
            "
          >
            Alpha Mission Control
          </h1>

          <p
            className="
              mt-4
              text-lg
              text-[#6B7280]
              max-w-2xl
            "
          >
            Real-time logistics dispatch,
            supplier coordination,
            driver monitoring,
            and delivery operations.
          </p>

        </div>

        {/* RIGHT PANEL */}

        <div
          className="
            bg-white
            border
            border-gray-200
            rounded-3xl
            p-6
            shadow-sm
            min-w-[320px]
          "
        >

          <div
            className="
              flex
              items-center
              justify-between
              mb-6
            "
          >

            <div>

              <p className="text-sm text-gray-500">
                System Status
              </p>

              <div
                className="
                  flex
                  items-center
                  gap-2
                  mt-2
                "
              >

                <div
                  className="
                    w-3
                    h-3
                    rounded-full
                    bg-green-500
                  "
                />

                <span className="font-semibold">
                  Operational
                </span>

              </div>

            </div>

            <div
              className="
                w-14
                h-14
                rounded-2xl
                bg-blue-50
                flex
                items-center
                justify-center
              "
            >

              <RefreshCcw
                className="
                  text-blue-600
                "
              />

            </div>

          </div>

          <div
            className="
              grid
              grid-cols-2
              gap-4
            "
          >

            <div
              className="
                bg-gray-50
                rounded-2xl
                p-4
              "
            >

              <p className="text-sm text-gray-500">
                Auto Refresh
              </p>

              <p
                className="
                  text-xl
                  font-bold
                  mt-2
                "
              >
                15s
              </p>

            </div>

            <div
              className="
                bg-gray-50
                rounded-2xl
                p-4
              "
            >

              <p className="text-sm text-gray-500">
                Environment
              </p>

              <p
                className="
                  text-xl
                  font-bold
                  mt-2
                  text-blue-600
                "
              >
                LIVE
              </p>

            </div>

          </div>

        </div>

      </div>

      {/* STATUS */}

      <StatusCards />

      {/* PROVIDERS */}

      <div
        className="
          grid
          grid-cols-1
          2xl:grid-cols-2
          gap-6
        "
      >

        <AvailabilityBoard
          type="suppliers"
        />

        <AvailabilityBoard
          type="drivers"
        />

      </div>

      {/* ORDERS */}

      <ActiveOrdersTable />

    </div>
  );
}